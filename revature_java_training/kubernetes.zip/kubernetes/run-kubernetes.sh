kubectl apply -f ./angular.yaml
kubectl apply -f ./spring.yaml