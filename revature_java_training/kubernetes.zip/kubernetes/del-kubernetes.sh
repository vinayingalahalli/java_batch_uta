kubectl delete deployment animals-angular-deployment
kubectl delete deployment animals-spring-deployment
kubectl delete service animals-angular-service
kubectl delete service animals-spring-service